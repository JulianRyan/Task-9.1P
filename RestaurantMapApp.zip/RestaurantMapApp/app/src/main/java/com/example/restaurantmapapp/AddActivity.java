package com.example.restaurantmapapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AddActivity extends AppCompatActivity {

    EditText nameEditText;
    EditText locationEditText;
    Button getLocationButton;
    Button showLocationButton;
    Button saveButton;
    Double latitude;
    Double longitude;
    String place;
    ArrayList<MarkerOptions> markers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        nameEditText = findViewById(R.id.nameEditText);
        locationEditText = findViewById(R.id.locationEditText);
        getLocationButton = findViewById(R.id.getLocationButton);
        showLocationButton = findViewById(R.id.showLocationButton);
        saveButton = findViewById(R.id.saveButton);
        try {
            latitude = getIntent().getDoubleExtra("Latitude", 0);
            longitude = getIntent().getDoubleExtra("Longitude", 0);
            place = getIntent().getStringExtra("Place");
            if (latitude != null) locationEditText.setText(latitude.toString() + ", " + longitude.toString());
            if (place != null) nameEditText.setText(place);
        }
        catch (Exception exception)
        {
            locationEditText.setText("Location");
        }
        Bundle args = getIntent().getBundleExtra("Markers");
        markers = (ArrayList<MarkerOptions>) args.getSerializable("Serializable");
        getLocationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(AddActivity.this, SearchActivity.class);
                Bundle args = new Bundle();
                args.putSerializable("Serializable",(Serializable)markers);
                intent.putExtra("Markers", args);
                startActivity(intent);
            }
        });
        showLocationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                String[] coordinates = locationEditText.getText().toString().split(",");
                latitude = Double.parseDouble(coordinates[0]);
                longitude = Double.parseDouble(coordinates[1]);
                Bundle args = getIntent().getBundleExtra("Markers");
                markers = (ArrayList<MarkerOptions>) args.getSerializable("Serializable");
                Intent intent = new Intent(AddActivity.this, MapsActivity.class);
                intent.putExtra("Latitude", latitude);
                intent.putExtra("Longitude", longitude);
                intent.putExtra("Place", place);
                intent.putExtra("SingleLocation", true);
                intent.putExtra("Markers", args);
                startActivity(intent);
            }
        });
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                String[] coordinates = locationEditText.getText().toString().split(",");
                latitude = Double.parseDouble(coordinates[0]);
                longitude = Double.parseDouble(coordinates[1]);
                MarkerOptions marker = new MarkerOptions();
                marker.position(new LatLng(latitude, longitude)).title("Marker in Sydney");
                markers.add(marker);
                Intent intent = new Intent(AddActivity.this, MainActivity.class);
                Bundle args = new Bundle();
                args.putSerializable("Serializable",(Serializable)markers);
                intent.putExtra("Markers", args);
                startActivity(intent);
            }
        });
    }
}