package com.example.restaurantmapapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.maps.model.MarkerOptions;

import java.io.Serializable;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button addPlaceButton;
    Button showAllButton;
    ArrayList<MarkerOptions> markers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        try {
            Bundle args = getIntent().getBundleExtra("Markers");
            markers = (ArrayList<MarkerOptions>) args.getSerializable("Serializable");
        }
        catch (Exception exception)
        {

        }
        if (markers == null) markers = new ArrayList<MarkerOptions>();
        addPlaceButton = findViewById(R.id.addPlaceButton);
        showAllButton = findViewById(R.id.showAllButton);
        addPlaceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Bundle args = new Bundle();
                args.putSerializable("Serializable",(Serializable)markers);
                Intent intent = new Intent(MainActivity.this, AddActivity.class);
                intent.putExtra("Markers", args);
                startActivity(intent);
            }
        });
        showAllButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Bundle args = new Bundle();
                Boolean singleLocation = false;
                args.putSerializable("Serializable",(Serializable)markers);
                Intent intent = new Intent(MainActivity.this, MapsActivity.class);
                intent.putExtra("Markers", args);
                intent.putExtra("SingleLocation", singleLocation);
                startActivity(intent);
            }
        });
    }
}